import express from "express";
import multer from "multer";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    cb(null, ["image/jpeg", "image/png", "image/webp"].includes(file.mimetype));
  }
});
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => {
  res.json({ photoAnalysisReady: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/analyze-photo", upload.single("photo"), async (req, res) => {
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: "Анализ фото пока не подключён. Добавьте OPENAI_API_KEY в файл .env." });
  }
  if (!req.file) return res.status(400).json({ error: "Выберите фото блюда в формате JPG, PNG или WEBP." });

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6.2-astra",
      input: [{
        role: "user",
        content: [
          { type: "input_text", text: `Проанализируй фото еды. Оцени видимые продукты и примерный размер порции. Верни только корректный JSON без markdown в формате:
{"dish":"название блюда","portion_g":"примерная масса порции в граммах или null","calories_kcal":число,"protein_g":число,"fat_g":число,"carbs_g":число,"ingredients":["ингредиент 1"],"notes":"коротко объясни, что оценка приблизительная и какие допущения сделаны"}.
Не выдумывай точность: если состав или размер порции неясны, явно укажи это в notes и используй диапазонную оценку, представив среднее число. Не делай медицинских выводов.` },
          { type: "input_image", image_url: dataUrl, detail: "high" }
        ]
      }]
    });
    const raw = response.output_text || "";
    const clean = raw.replace(/```json|```/g, "").trim();
    const result = JSON.parse(clean);
    res.json(result);
  } catch (err) {
    console.error("Photo analysis error:", err.message);
    res.status(500).json({ error: "Не удалось распознать блюдо. Попробуйте более чёткое фото с хорошим освещением." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Healthy Menu запущено: http://localhost:${port}`));
